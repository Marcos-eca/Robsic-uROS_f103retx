/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "adc.h"
#include "dma.h"
#include "usart.h"
#include "gpio.h"
#include "stm32f1xx_it.h"



#include <time.h>
#include <rcl/rcl.h>
#include <rcl/error_handling.h>
#include <rclc/rclc.h>
#include <rclc/executor.h>
#include <uxr/client/transport.h>
#include <rmw_microxrcedds_c/config.h>
#include <rmw_microros/rmw_microros.h>

#include <std_msgs/msg/int32.h>
#include <std_msgs/msg/float32_multi_array.h>
#include <nav_msgs/msg/odometry.h>

#include <sensor_msgs/msg/joint_state.h>

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
typedef StaticTask_t osStaticThreadDef_t;
/* USER CODE BEGIN PTD */

uint32_t count_a;
uint32_t count_b;
uint32_t Nmax_rev=2000;
float angle_resolution=0.05;
float Ts=0.1;

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{

   if(GPIO_Pin == GPIO_PIN_0){
	   if(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_8))
          count_a++;
	   else
		  count_a--;
   }

   if(GPIO_Pin == GPIO_PIN_1){
	   if(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_9))
          count_b++;
	   else
 		  count_b--;
   }

}
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */
uint16_t analog_data_input_manual[2]={0,0};

std_msgs__msg__Float32MultiArray velocity_and_voltage_msg;
nav_msgs__msg__Odometry odom;
sensor_msgs__msg__JointState joint_steering;

rcl_publisher_t velocity_and_voltage_pub;
rcl_publisher_t odom_pub;
rcl_publisher_t ros2_joint_steering_pub;

rcl_timer_t velocity_and_voltage_timer;
rcl_timer_t odom_timer;
rcl_timer_t golfinho_joint_steering_timer;

/* USER CODE END Variables */
/* Definitions for uros */
osThreadId_t urosHandle;
uint32_t urosBuffer[ 3000 ];
osStaticThreadDef_t urosControlBlock;
const osThreadAttr_t uros_attributes = {
  .name = "uros",
  .cb_mem = &urosControlBlock,
  .cb_size = sizeof(urosControlBlock),
  .stack_mem = &urosBuffer[0],
  .stack_size = sizeof(urosBuffer),
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for analog */
osThreadId_t analogHandle;
const osThreadAttr_t analog_attributes = {
  .name = "analog",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */

bool cubemx_transport_open(struct uxrCustomTransport * transport);
bool cubemx_transport_close(struct uxrCustomTransport * transport);
size_t cubemx_transport_write(struct uxrCustomTransport* transport, const uint8_t * buf, size_t len, uint8_t * err);
size_t cubemx_transport_read(struct uxrCustomTransport* transport, uint8_t* buf, size_t len, int timeout, uint8_t* err);

void * microros_allocate(size_t size, void * state);
void microros_deallocate(void * pointer, void * state);
void * microros_reallocate(void * pointer, size_t size, void * state);
void * microros_zero_allocate(size_t number_of_elements, size_t size_of_element, void * state);

void velocity_and_voltage_timer_callback(rcl_timer_t * timer, int64_t last_call_time);
void odom_callback(rcl_timer_t * timer, int64_t last_call_time);
void golfinho_joint_steering_timer_callback(rcl_timer_t * timer, int64_t last_call_time);
void ADC_select_channel_break (void);
void ADC_select_channel_Throttle (void);
/* USER CODE END FunctionPrototypes */

void urosTask(void *argument);
void analogTask02(void *argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of uros */
  urosHandle = osThreadNew(urosTask, NULL, &uros_attributes);

  /* creation of analog */
  analogHandle = osThreadNew(analogTask02, NULL, &analog_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* add events, ... */
  /* USER CODE END RTOS_EVENTS */

}

/* USER CODE BEGIN Header_urosTask */
/**
  * @brief  Function implementing the uros thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_urosTask */
void urosTask(void *argument)
{
  /* USER CODE BEGIN urosTask */

	// micro-ROS configuration
			  rmw_uros_set_custom_transport(
				true,
				(void *) &huart2,
				cubemx_transport_open,
				cubemx_transport_close,
				cubemx_transport_write,
				cubemx_transport_read);

			  rcl_allocator_t freeRTOS_allocator = rcutils_get_zero_initialized_allocator();
			  freeRTOS_allocator.allocate = microros_allocate;
			  freeRTOS_allocator.deallocate = microros_deallocate;
			  freeRTOS_allocator.reallocate = microros_reallocate;
			  freeRTOS_allocator.zero_allocate =  microros_zero_allocate;

		  if (!rcutils_set_default_allocator(&freeRTOS_allocator)) {
			  printf("Error on default allocators (line %d)\n", __LINE__);
		  }

		  rclc_support_t support;
		  rcl_allocator_t allocator;
		  rcl_node_t node;
		  rclc_executor_t executor;
		  rcl_init_options_t init_options;

		  allocator = rcl_get_default_allocator();
		  init_options = rcl_get_zero_initialized_init_options();
		  rcl_init_options_init(&init_options, allocator);

		  // create init_options
		  rclc_support_init_with_options(&support, 0, NULL, &init_options, &allocator);

		  // create node
		   rclc_node_init_default(&node, "golfinho", "acquisition_data", &support);

		  //time sync
		  if( rmw_uros_sync_session(1000) != RMW_RET_OK)
			  printf("Error on time sync (line %d)\n", __LINE__);

		  // ros2_motion_info_pub
		  rclc_publisher_init_default(
				  &velocity_and_voltage_pub,
				  &node,
				  ROSIDL_GET_MSG_TYPE_SUPPORT(std_msgs, msg, Float32MultiArray),
				  "/velocity_and_voltage_data");

		  rclc_publisher_init_default(
				  &odom_pub,
				  &node,
				  ROSIDL_GET_MSG_TYPE_SUPPORT(nav_msgs, msg, Odometry),
				  "/odom");

		  // ros2_joint_steering_pub
		  rclc_publisher_init_default(
				  &ros2_joint_steering_pub,
				  &node,
				  ROSIDL_GET_MSG_TYPE_SUPPORT(sensor_msgs, msg, JointState),
				  "/golfinho/joint_steering");

			 	velocity_and_voltage_msg.data.capacity = 4;
			 	velocity_and_voltage_msg.data.size = 4;
			 	velocity_and_voltage_msg.data.data = (uint16_t*) pvPortMalloc(velocity_and_voltage_msg.data.capacity * sizeof(uint16_t));
			 	velocity_and_voltage_msg.layout.dim.capacity = 6;
			 	velocity_and_voltage_msg.layout.dim.size = 6;
			 	velocity_and_voltage_msg.layout.dim.data = (std_msgs__msg__MultiArrayDimension*) pvPortMalloc(velocity_and_voltage_msg.layout.dim.capacity * sizeof(std_msgs__msg__MultiArrayDimension));
				 	  for (size_t i =0; i< velocity_and_voltage_msg.layout.dim.capacity; i++){
				 		velocity_and_voltage_msg.layout.dim.data[i].label.capacity = 9;
				 		velocity_and_voltage_msg.layout.dim.data[i].label.size = 9;
				 		velocity_and_voltage_msg.layout.dim.data[i].label.data = (char*) pvPortMalloc(velocity_and_voltage_msg.layout.dim.data[i].label.capacity * sizeof(char));
				 	  }

				 	  strcpy(velocity_and_voltage_msg.layout.dim.data[0].label.data, "right_whell");
				 	  strcpy(velocity_and_voltage_msg.layout.dim.data[1].label.data, "left_whell");
				 	  strcpy(velocity_and_voltage_msg.layout.dim.data[2].label.data, "throt_volt");
		              strcpy(velocity_and_voltage_msg.layout.dim.data[3].label.data, "break_volt");
		//odom


                            int STRING_BUFFER_LEN=10;
					    	char odom_buffer[STRING_BUFFER_LEN];
					    	odom.header.frame_id.data = odom_buffer;
					    	odom.header.frame_id.capacity = STRING_BUFFER_LEN;

					    	char child_frame__id[15];
					    	odom.child_frame_id.data=child_frame__id;
					    	odom.child_frame_id.capacity=16;



					    	// joint_steering

					    				    	char joint_steering_buffer[STRING_BUFFER_LEN];
					    				    	joint_steering.header.frame_id.data = joint_steering_buffer;
					    				    	joint_steering.header.frame_id.capacity = STRING_BUFFER_LEN;

					    				    	joint_steering.name.capacity=1;
					    						joint_steering.name.size=1;
					    						joint_steering.name.data=(rosidl_runtime_c__String *) pvPortMalloc(joint_steering.name.capacity * sizeof(rosidl_runtime_c__String));

					    						joint_steering.name.data->capacity=5;
					    						joint_steering.name.data->size=5;
					    						joint_steering.name.data->data=(char*) pvPortMalloc(joint_steering.name.capacity * sizeof(char));
					    					 	strcpy(joint_steering.name.data->data, "steer");

					    					 	joint_steering.velocity.capacity=1;
					    					 	joint_steering.velocity.size=1;
					    					 	joint_steering.velocity.data=(double*) pvPortMalloc(joint_steering.name.capacity * sizeof(double));

					    					 	joint_steering.position.capacity=1;
					    					 	joint_steering.position.size=1;
					    					 	joint_steering.position.data=(double*) pvPortMalloc(joint_steering.name.capacity * sizeof(double));

					    					 	joint_steering.effort.capacity=1;
					    					 	joint_steering.effort.size=1;
					    					 	joint_steering.effort.data=(double*) pvPortMalloc(joint_steering.name.capacity * sizeof(double));



		  // Create a timer
		  rclc_timer_init_default(&velocity_and_voltage_timer, &support, RCL_MS_TO_NS(100), velocity_and_voltage_timer_callback);
		  rclc_timer_init_default(&golfinho_joint_steering_timer, &support, RCL_MS_TO_NS(100), golfinho_joint_steering_timer_callback);
		  rclc_timer_init_default(&odom_timer, &support, RCL_MS_TO_NS(1000), odom_callback);
		  // Create executor
		  rclc_executor_init(&executor, &support.context,3, &allocator);
		  rclc_executor_add_timer(&executor, &golfinho_joint_steering_timer);
		  rclc_executor_add_timer(&executor, &velocity_and_voltage_timer);
		  rclc_executor_add_timer(&executor, &odom_timer);

	      // Run executor
		  rclc_executor_spin(&executor);

		  /* Infinite loop */
		  for(;;) osDelay(10);
  /* USER CODE END urosTask */
}

/* USER CODE BEGIN Header_analogTask02 */
/**
* @brief Function implementing the analog thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_analogTask02 */
void analogTask02(void *argument)
{
  /* USER CODE BEGIN analogTask02 */
  /* Infinite loop */
	  for(;;)
	  {
		  // Get ADC value
			  ADC_select_channel_Throttle();
			  HAL_ADC_Start(&hadc1);
			  HAL_ADC_PollForConversion(&hadc1, 10);
			  analog_data_input_manual[0] = HAL_ADC_GetValue(&hadc1);
			  HAL_ADC_Stop(&hadc1);

		          ADC_select_channel_break();
			  HAL_ADC_Start(&hadc1);
			  HAL_ADC_PollForConversion(&hadc1, 10);
			  analog_data_input_manual[1] = HAL_ADC_GetValue(&hadc1);
			  HAL_ADC_Stop(&hadc1);

			  HAL_Delay(20);
	  }
  /* USER CODE END analogTask02 */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */

void odom_callback(rcl_timer_t * timer, int64_t last_call_time)
{
	int device_id=4321;
	int seq_no=15;

	(void) last_call_time;

	if (timer != NULL) {

		sprintf(odom.header.frame_id.data, "%d_%d", seq_no, device_id);
		odom.header.frame_id.size = strlen(odom.header.frame_id.data);

		sprintf(odom.child_frame_id.data, "%d_%d", seq_no, device_id);
		odom.child_frame_id.size = strlen(odom.child_frame_id.data);


		// Fill the message timestamp
		struct timespec ts;
		clock_gettime(CLOCK_REALTIME, &ts);
		odom.header.stamp.sec = ts.tv_sec;
		odom.header.stamp.nanosec = ts.tv_nsec;

		rcl_ret_t ret = rcl_publish(&odom_pub,&odom, NULL);

		if (ret != RCL_RET_OK)
		{
		  printf("Error publishing gpio inputs (line %d)\n", __LINE__);
		}
   }
}

void velocity_and_voltage_timer_callback(rcl_timer_t * timer, int64_t last_call_time){
		       velocity_and_voltage_msg.data.data[0]=(count_a/Nmax_rev)*angle_resolution/Ts; count_a=0;
		       velocity_and_voltage_msg.data.data[1]=(count_b/Nmax_rev)*angle_resolution/Ts; count_b=0;
		       velocity_and_voltage_msg.data.data[2]=analog_data_input_manual[0];
		       velocity_and_voltage_msg.data.data[3]=analog_data_input_manual[1];
		// Publish the message
		rcl_ret_t ret = rcl_publish(&velocity_and_voltage_pub,&velocity_and_voltage_msg, NULL);
		if (ret != RCL_RET_OK){
		  printf("Error publishing gpio inputs (line %d)\n", __LINE__);
		}
}




void golfinho_joint_steering_timer_callback(rcl_timer_t * timer, int64_t last_call_time)
{
	int device_id=012;
	int seq_no=01;
	double data0=90,data1,data2;

	(void) last_call_time;

	if (timer != NULL) {

		sprintf(joint_steering.header.frame_id.data, "%d_%d", seq_no, device_id);
		joint_steering.header.frame_id.size = strlen(joint_steering.header.frame_id.data);

		// Fill the message timestamp
		struct timespec ts;
		clock_gettime(CLOCK_REALTIME, &ts);
		joint_steering.header.stamp.sec = ts.tv_sec;
		joint_steering.header.stamp.nanosec = ts.tv_nsec;

		joint_steering.position.data=&data0;
		joint_steering.velocity.data=&data0;
		joint_steering.effort.data=&data0;

		rcl_ret_t ret = rcl_publish(&ros2_joint_steering_pub,&joint_steering, NULL);

		if (ret != RCL_RET_OK)
		{
		  printf("Error publishing gpio inputs (line %d)\n", __LINE__);
		}
	}

}






void ADC_select_channel_break (void)
{
	ADC_ChannelConfTypeDef sConfig = {0};
	  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
	  */
      sConfig.Channel = ADC_CHANNEL_4;
	  sConfig.Rank = ADC_REGULAR_RANK_1;
	  sConfig.SamplingTime = ADC_SAMPLETIME_1CYCLE_5;
	  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
	  {
	    Error_Handler();
	  }
}

void ADC_select_channel_Throttle (void)
{
	ADC_ChannelConfTypeDef sConfig = {0};
	  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
	  */
	  sConfig.Channel = ADC_CHANNEL_5;
	  sConfig.Rank = ADC_REGULAR_RANK_1;
	  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
	  {
	    Error_Handler();
	  }
}
/* USER CODE END Application */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
